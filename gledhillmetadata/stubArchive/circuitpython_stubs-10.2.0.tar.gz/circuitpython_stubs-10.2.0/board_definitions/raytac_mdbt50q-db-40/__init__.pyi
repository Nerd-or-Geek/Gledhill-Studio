# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for MDBT50Q-DB-40
 - port: nordic
 - board_id: raytac_mdbt50q-db-40
 - NVM size: 8192
 - Included modules: _asyncio, _bleio, _bleio (native), _pixelmap, adafruit_bus_device, adafruit_pixelbuf, aesio, alarm, analogio, array, atexit, audiobusio, audiocore, audiomixer, audiomp3, audiopwmio, binascii, bitbangio, bitmapfilter, bitmaptools, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, codeop, collections, countio, digitalio, displayio, epaperdisplay, errno, fontio, fourwire, framebufferio, getpass, gifio, hashlib, i2cdisplaybus, io, jpegio, json, keypad, keypad.KeyMatrix, keypad.Keys, keypad.ShiftRegisterKeys, keypad_demux, keypad_demux.DemuxKeyMatrix, locale, lvfontio, math, memorymap, microcontroller, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, paralleldisplaybus, pulseio, pwmio, rainbowio, random, re, rgbmatrix, rotaryio, rtc, sdcardio, select, sharpdisplay, storage, struct, supervisor, supervisor.get_setting, synthio, sys, terminalio, tilepalettemapper, time, touchio, traceback, ulab, usb_cdc, usb_hid, usb_midi, vectorio, warnings, watchdog, zlib
 - Frozen libraries: 
"""

# Imports
import microcontroller


# Board Info:
board_id: str


# Pins:
P0_02: microcontroller.Pin  # P0_02
P0_03: microcontroller.Pin  # P0_03
P0_04: microcontroller.Pin  # P0_04
P0_05: microcontroller.Pin  # P0_05
P0_06: microcontroller.Pin  # P0_06
P0_07: microcontroller.Pin  # P0_07
P0_08: microcontroller.Pin  # P0_08
P0_09: microcontroller.Pin  # P0_09
P0_10: microcontroller.Pin  # P0_10
P0_11: microcontroller.Pin  # P0_11
P0_12: microcontroller.Pin  # P0_12
P0_13: microcontroller.Pin  # P0_13
P0_14: microcontroller.Pin  # P0_14
P0_15: microcontroller.Pin  # P0_15
P0_16: microcontroller.Pin  # P0_16
P0_17: microcontroller.Pin  # P0_17
P0_18: microcontroller.Pin  # P0_18
P0_19: microcontroller.Pin  # P0_19
P0_20: microcontroller.Pin  # P0_20
P0_21: microcontroller.Pin  # P0_21
P0_22: microcontroller.Pin  # P0_22
P0_23: microcontroller.Pin  # P0_23
P0_24: microcontroller.Pin  # P0_24
P0_25: microcontroller.Pin  # P0_25
P0_26: microcontroller.Pin  # P0_26
P0_27: microcontroller.Pin  # P0_27
P0_28: microcontroller.Pin  # P0_28
P0_29: microcontroller.Pin  # P0_29
P0_30: microcontroller.Pin  # P0_30
P0_31: microcontroller.Pin  # P0_31
P1_00: microcontroller.Pin  # P1_00
P1_01: microcontroller.Pin  # P1_01
P1_02: microcontroller.Pin  # P1_02
P1_03: microcontroller.Pin  # P1_03
P1_04: microcontroller.Pin  # P1_04
P1_05: microcontroller.Pin  # P1_05
P1_06: microcontroller.Pin  # P1_06
P1_07: microcontroller.Pin  # P1_07
P1_08: microcontroller.Pin  # P1_08
P1_09: microcontroller.Pin  # P1_09
P1_10: microcontroller.Pin  # P1_10
P1_11: microcontroller.Pin  # P1_11
P1_12: microcontroller.Pin  # P1_12
P1_13: microcontroller.Pin  # P1_13
P1_14: microcontroller.Pin  # P1_14
P1_15: microcontroller.Pin  # P1_15
AIN_0: microcontroller.Pin  # P0_02
AIN_1: microcontroller.Pin  # P0_03
AIN_2: microcontroller.Pin  # P0_04
AIN_3: microcontroller.Pin  # P0_05
AIN_4: microcontroller.Pin  # P0_28
AIN_5: microcontroller.Pin  # P0_29
AIN_6: microcontroller.Pin  # P0_30
AIN_7: microcontroller.Pin  # P0_31
NFC_1: microcontroller.Pin  # P0_09
NFC_2: microcontroller.Pin  # P0_10
TX: microcontroller.Pin  # P0_06
RX: microcontroller.Pin  # P0_08
CTS: microcontroller.Pin  # P0_07
RTS: microcontroller.Pin  # P0_05
LED_R: microcontroller.Pin  # P0_14
LED_G: microcontroller.Pin  # P0_13
LED_B: microcontroller.Pin  # P0_15
LED_4: microcontroller.Pin  # P0_16
SW1: microcontroller.Pin  # P0_11
SW2: microcontroller.Pin  # P0_12
SW3: microcontroller.Pin  # P0_24
SW4: microcontroller.Pin  # P0_25


# Members:

# Unmapped:
#   none
