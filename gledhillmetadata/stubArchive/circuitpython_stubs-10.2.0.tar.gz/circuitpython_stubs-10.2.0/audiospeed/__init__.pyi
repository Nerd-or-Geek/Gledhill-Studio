"""Audio processing tools"""

from __future__ import annotations

import circuitpython_typing

class SpeedChanger:
    """Wraps an audio sample to play it back at a different speed.

    Uses nearest-neighbor resampling with a fixed-point phase accumulator
    for CPU-efficient variable-speed playback."""

    def __init__(
        self, source: circuitpython_typing.AudioSample, rate: float = 1.0
    ) -> None:
        """Create a SpeedChanger that wraps ``source``.

        :param audiosample source: The audio source to resample.
        :param float rate: Playback speed multiplier. 1.0 = normal, 2.0 = double speed,
          0.5 = half speed. Must be positive.

        Playing a wave file at 1.5x speed::

          import board
          import audiocore
          import audiospeed
          import audioio

          wav = audiocore.WaveFile("drum.wav")
          fast = audiospeed.SpeedChanger(wav, rate=1.5)
          audio = audioio.AudioOut(board.A0)
          audio.play(fast)

          # Change speed during playback:
          fast.rate = 2.0   # double speed
          fast.rate = 0.5   # half speed
        """
        ...

    def deinit(self) -> None:
        """Deinitialises the SpeedChanger and releases all memory resources for reuse."""
        ...
    rate: float
    """Playback speed multiplier. Can be changed during playback."""
